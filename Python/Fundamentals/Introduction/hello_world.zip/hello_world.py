print("Hello World!")
name = "Tristan!"
print(name)
print("Hello", name)
print("hello" + name)

name = 51
print("Hello", name)
print('hello' +  str(51))

fave_food1 = "Chinese Food"
fave_food2 = "Moms Cooking"
print("Food I love to eat are {} and {}".format(fave_food1, fave_food2))
print(f"Two of my favorite foods are {fave_food1} and {fave_food2}")